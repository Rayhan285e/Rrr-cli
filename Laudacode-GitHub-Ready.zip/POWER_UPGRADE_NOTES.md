# Laudacode Power Upgrade — Change Notes

This package is based on the supplied `Laudacode-main.zip`. The supplied `opencode-dev.zip` was inspected as an architectural reference; its TypeScript/Bun runtime was not copied into this Rust/Termux project.

## Scope preserved

- No redesign or replacement of the existing TUI, theme, colors, layout, banner effects, animations, or visual identity.
- No new third-party dependencies; `Cargo.toml` and `Cargo.lock` remain unchanged.
- Existing command names, tool schemas, provider configuration, permission model, and project architecture are preserved.

## Power improvements

1. **Longer autonomous turns:** the old hard-coded 30 model/tool rounds are now configurable with `[limits].max_tool_rounds`. Default: 100; accepted effective range: 1–200. The value is clamped at runtime to prevent an accidental unbounded loop.
2. **Config persistence:** the new limit participates in the config default check, so a config containing only `max_tool_rounds` is not silently omitted when saved. A round-trip regression test was added.
3. **Terminal-agent behavior:** the system instructions now explicitly cover practical terminal/environment operations, environment detection, Termux capability checks, long-running process tools, careful recovery from edit-pattern mismatches, verification, and resumable checkpoints.
4. **Bounded command output:** one-shot shell and Git output is drained incrementally and only the newest bounded output is retained. This prevents a very noisy process from growing memory without limit and preserves the most useful final diagnostics.
5. **Reliable timeout cleanup:** cancellation and timeout now terminate the entire shell process group, not just the shell process, reducing orphaned compilers/package managers and child processes.
6. **Managed process output:** retained output per stream is increased from 8 KiB to 32 KiB. The existing 16-process cap remains to avoid exhausting low-memory Termux devices. Mutex poisoning is recovered without panicking.

## OpenCode reference review

The reference project was used to compare shell lifecycle, background execution, permission handling, tool-result truncation, and agent workflow patterns. Only concepts compatible with Laudacode's lightweight Rust/Termux architecture were adapted. OpenCode's UI and runtime were not imported.

## Verification status

- ZIP integrity and source-file consistency should be checked after extraction.
- **Rust compilation and tests were not run in the creation environment because `cargo`/`rustc` were unavailable and installing the toolchain timed out.** Do not treat this package as build-verified yet.
- On Termux, install the Rust toolchain and run:

```sh
pkg update
pkg install rust git -y
cargo fmt --check
cargo check --locked
cargo test --locked
cargo build --release --locked
```

- Existing config files remain compatible. To change the per-turn round limit, add this under `[limits]` in `~/.config/laudacode/config.toml`:

```toml
[limits]
max_tool_rounds = 100
```

Values above 200 are clamped to 200. Raising the round limit can increase API usage and cost; keep token/cost guardrails configured as needed.
