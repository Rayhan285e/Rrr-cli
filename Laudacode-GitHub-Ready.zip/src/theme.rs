//! UI themes — one struct describing every palette slot (syntax, chrome and
//! banner), seventeen built-ins, swappable at runtime via `/theme`.

use ratatui::style::Color;

/// Every color the TUI, markdown renderer and syntax highlighter use.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Theme {
    pub name: &'static str,
    /// Primary accent (tool-ok, edit marks, composer focus).
    pub accent: Color,
    /// Secondary accent (file headers, tool-call dot).
    pub accent2: Color,
    pub heading: Color,
    pub bullet: Color,
    pub text: Color,
    pub dim: Color,
    pub gray: Color,
    pub success: Color,
    pub error: Color,
    pub warning: Color,
    pub user: Color,
    pub mode_plan: Color,
    pub mode_build: Color,
    pub mode_full: Color,
    pub code_fg: Color,
    pub code_bg: Color,
    pub rule: Color,
    pub add_bg: Color,
    pub del_bg: Color,
    // Syntax tokens.
    pub kw: Color,
    pub string: Color,
    pub comment: Color,
    pub num: Color,
    pub ty: Color,
    pub func: Color,
    pub mac: Color,
    pub op: Color,
    /// Banner gradient stops: top / middle / bottom.
    pub banner: [Color; 3],
    // Chrome slots — the structural surfaces the TUI is built from. Keeping
    // these in the palette means `/theme` restyles every panel, popup and
    // status bar at once instead of leaving hardcoded greys behind.
    /// Box-drawing borders of unfocused panels/modals/popups.
    pub border: Color,
    /// Border of the focused widget (composer, live picker, dimmed modal).
    pub border_focus: Color,
    /// Selected-row background (picker, popup, list highlight).
    pub surface: Color,
    /// Selected-row foreground — must contrast with [`Theme::surface`].
    pub surface_fg: Color,
    /// Key cap on a key-hint chip, e.g. the `enter` in "enter send".
    pub hint_key: Color,
    /// Label part of a key-hint chip, e.g. the `send` above.
    pub hint_text: Color,
    /// Filled cells of a context/progress meter.
    pub bar_fill: Color,
    /// Empty cells of a context/progress meter.
    pub bar_empty: Color,
    /// Scrim painted behind a floating popup (dims the transcript).
    pub overlay: Color,
}

const fn rgb(r: u8, g: u8, b: u8) -> Color {
    Color::Rgb(r, g, b)
}

/// Current look — greens flowing into cyan/blue.
pub static LAUDA: Theme = Theme {
    name: "lauda",
    accent: Color::LightGreen,
    accent2: Color::Cyan,
    heading: Color::LightBlue,
    bullet: Color::LightMagenta,
    text: Color::White,
    dim: Color::DarkGray,
    gray: Color::Gray,
    success: Color::LightGreen,
    error: Color::LightRed,
    warning: Color::LightYellow,
    user: Color::LightCyan,
    mode_plan: Color::LightBlue,
    mode_build: Color::LightGreen,
    mode_full: Color::Yellow,
    code_fg: Color::LightYellow,
    code_bg: rgb(35, 35, 50),
    rule: rgb(95, 95, 120),
    add_bg: rgb(24, 48, 30),
    del_bg: rgb(56, 26, 30),
    kw: Color::LightMagenta,
    string: Color::LightGreen,
    comment: Color::DarkGray,
    num: Color::LightYellow,
    ty: Color::Yellow,
    func: Color::LightBlue,
    mac: Color::LightRed,
    op: Color::Cyan,
    banner: [Color::LightGreen, Color::LightCyan, Color::Blue],
    border: rgb(85, 88, 112),
    border_focus: Color::LightGreen,
    surface: rgb(42, 52, 60),
    surface_fg: Color::White,
    hint_key: Color::LightGreen,
    hint_text: rgb(120, 124, 148),
    bar_fill: Color::LightGreen,
    bar_empty: rgb(60, 62, 82),
    overlay: Color::Black,
};

/// Sakura — soft rose and plum, made for the petals effect.
pub static CHERRY: Theme = Theme {
    name: "cherry",
    accent: rgb(255, 158, 189),
    accent2: rgb(255, 199, 216),
    heading: rgb(255, 183, 214),
    bullet: rgb(255, 145, 175),
    text: rgb(255, 236, 242),
    dim: rgb(120, 90, 105),
    gray: rgb(190, 155, 170),
    success: rgb(160, 235, 180),
    error: rgb(255, 110, 130),
    warning: rgb(255, 205, 140),
    user: rgb(255, 210, 226),
    mode_plan: rgb(198, 166, 255),
    mode_build: rgb(255, 158, 189),
    mode_full: rgb(255, 196, 120),
    code_fg: rgb(255, 200, 220),
    code_bg: rgb(48, 26, 38),
    rule: rgb(120, 70, 92),
    add_bg: rgb(52, 28, 40),
    del_bg: rgb(70, 28, 36),
    kw: rgb(255, 121, 198),
    string: rgb(195, 232, 141),
    comment: rgb(108, 88, 100),
    num: rgb(247, 190, 120),
    ty: rgb(255, 214, 153),
    func: rgb(173, 205, 255),
    mac: rgb(255, 158, 120),
    op: rgb(255, 173, 205),
    banner: [rgb(255, 158, 189), rgb(255, 199, 216), rgb(186, 142, 255)],
    border: rgb(150, 96, 122),
    border_focus: rgb(255, 158, 189),
    surface: rgb(70, 40, 54),
    surface_fg: rgb(255, 236, 242),
    hint_key: rgb(255, 158, 189),
    hint_text: rgb(150, 116, 132),
    bar_fill: rgb(255, 158, 189),
    bar_empty: rgb(80, 48, 62),
    overlay: Color::Black,
};

/// Deep blue night sky.
pub static MIDNIGHT: Theme = Theme {
    name: "midnight",
    accent: rgb(126, 192, 255),
    accent2: rgb(112, 214, 255),
    heading: rgb(148, 176, 255),
    bullet: rgb(171, 157, 242),
    text: rgb(220, 228, 240),
    dim: rgb(90, 100, 125),
    gray: rgb(150, 162, 185),
    success: rgb(134, 236, 172),
    error: rgb(255, 128, 128),
    warning: rgb(255, 209, 130),
    user: rgb(140, 225, 255),
    mode_plan: rgb(148, 176, 255),
    mode_build: rgb(126, 222, 168),
    mode_full: rgb(255, 209, 130),
    code_fg: rgb(196, 214, 240),
    code_bg: rgb(18, 24, 44),
    rule: rgb(60, 72, 105),
    add_bg: rgb(20, 46, 34),
    del_bg: rgb(56, 26, 32),
    kw: rgb(198, 160, 255),
    string: rgb(134, 236, 172),
    comment: rgb(90, 100, 125),
    num: rgb(255, 213, 128),
    ty: rgb(126, 222, 234),
    func: rgb(126, 178, 255),
    mac: rgb(255, 145, 165),
    op: rgb(112, 214, 255),
    banner: [rgb(90, 130, 255), rgb(126, 192, 255), rgb(60, 68, 130)],
    border: rgb(56, 72, 110),
    border_focus: rgb(126, 192, 255),
    surface: rgb(38, 52, 88),
    surface_fg: rgb(230, 238, 250),
    hint_key: rgb(126, 192, 255),
    hint_text: rgb(110, 122, 150),
    bar_fill: rgb(126, 222, 168),
    bar_empty: rgb(42, 54, 84),
    overlay: Color::Black,
};

/// Cool blue-slate nordic palette.
pub static NORD: Theme = Theme {
    name: "nord",
    accent: rgb(136, 192, 208),
    accent2: rgb(129, 161, 193),
    heading: rgb(129, 161, 193),
    bullet: rgb(180, 142, 173),
    text: rgb(236, 239, 244),
    dim: rgb(76, 86, 106),
    gray: rgb(143, 152, 168),
    success: rgb(163, 190, 140),
    error: rgb(191, 97, 106),
    warning: rgb(235, 203, 139),
    user: rgb(136, 192, 208),
    mode_plan: rgb(129, 161, 193),
    mode_build: rgb(163, 190, 140),
    mode_full: rgb(235, 203, 139),
    code_fg: rgb(216, 222, 233),
    code_bg: rgb(46, 52, 64),
    rule: rgb(76, 86, 106),
    add_bg: rgb(46, 62, 50),
    del_bg: rgb(66, 42, 46),
    kw: rgb(129, 161, 193),
    string: rgb(163, 190, 140),
    comment: rgb(96, 106, 126),
    num: rgb(208, 135, 112),
    ty: rgb(235, 203, 139),
    func: rgb(136, 192, 208),
    mac: rgb(191, 97, 106),
    op: rgb(136, 192, 208),
    banner: [rgb(163, 190, 140), rgb(136, 192, 208), rgb(94, 129, 172)],
    border: rgb(86, 96, 116),
    border_focus: rgb(136, 192, 208),
    surface: rgb(66, 76, 96),
    surface_fg: rgb(236, 239, 244),
    hint_key: rgb(136, 192, 208),
    hint_text: rgb(120, 130, 150),
    bar_fill: rgb(163, 190, 140),
    bar_empty: rgb(62, 70, 88),
    overlay: Color::Black,
};

/// Purple-forward classic.
pub static DRACULA: Theme = Theme {
    name: "dracula",
    accent: rgb(189, 147, 249),
    accent2: rgb(139, 233, 253),
    heading: rgb(255, 184, 108),
    bullet: rgb(255, 121, 198),
    text: rgb(248, 248, 242),
    dim: rgb(98, 114, 164),
    gray: rgb(139, 143, 177),
    success: rgb(80, 250, 123),
    error: rgb(255, 85, 85),
    warning: rgb(241, 250, 140),
    user: rgb(139, 233, 253),
    mode_plan: rgb(189, 147, 249),
    mode_build: rgb(80, 250, 123),
    mode_full: rgb(241, 250, 140),
    code_fg: rgb(248, 248, 242),
    code_bg: rgb(40, 42, 54),
    rule: rgb(68, 71, 90),
    add_bg: rgb(38, 54, 44),
    del_bg: rgb(58, 38, 44),
    kw: rgb(255, 121, 198),
    string: rgb(241, 250, 140),
    comment: rgb(98, 114, 164),
    num: rgb(189, 147, 249),
    ty: rgb(139, 233, 253),
    func: rgb(80, 250, 123),
    mac: rgb(255, 85, 85),
    op: rgb(255, 184, 108),
    banner: [rgb(255, 121, 198), rgb(189, 147, 249), rgb(139, 233, 253)],
    border: rgb(88, 92, 128),
    border_focus: rgb(189, 147, 249),
    surface: rgb(58, 60, 88),
    surface_fg: rgb(248, 248, 242),
    hint_key: rgb(139, 233, 253),
    hint_text: rgb(130, 140, 175),
    bar_fill: rgb(80, 250, 123),
    bar_empty: rgb(58, 60, 82),
    overlay: Color::Black,
};

/// High-contrast retro warm.
pub static MONOKAI: Theme = Theme {
    name: "monokai",
    accent: rgb(166, 226, 46),
    accent2: rgb(102, 217, 239),
    heading: rgb(253, 151, 31),
    bullet: rgb(249, 38, 114),
    text: rgb(248, 248, 240),
    dim: rgb(117, 113, 94),
    gray: rgb(150, 145, 130),
    success: rgb(166, 226, 46),
    error: rgb(249, 38, 114),
    warning: rgb(230, 219, 116),
    user: rgb(102, 217, 239),
    mode_plan: rgb(102, 217, 239),
    mode_build: rgb(166, 226, 46),
    mode_full: rgb(230, 219, 116),
    code_fg: rgb(248, 248, 240),
    code_bg: rgb(39, 40, 34),
    rule: rgb(90, 89, 78),
    add_bg: rgb(48, 54, 34),
    del_bg: rgb(64, 32, 40),
    kw: rgb(249, 38, 114),
    string: rgb(230, 219, 116),
    comment: rgb(117, 113, 94),
    num: rgb(174, 129, 255),
    ty: rgb(102, 217, 239),
    func: rgb(166, 226, 46),
    mac: rgb(253, 151, 31),
    op: rgb(253, 151, 31),
    banner: [rgb(249, 38, 114), rgb(253, 151, 31), rgb(166, 226, 46)],
    border: rgb(96, 94, 80),
    border_focus: rgb(166, 226, 46),
    surface: rgb(62, 62, 52),
    surface_fg: rgb(248, 248, 240),
    hint_key: rgb(166, 226, 46),
    hint_text: rgb(140, 136, 118),
    bar_fill: rgb(166, 226, 46),
    bar_empty: rgb(58, 58, 48),
    overlay: Color::Black,
};

/// Warm sun-baked classic.
pub static SOLARIZED: Theme = Theme {
    name: "solarized",
    accent: rgb(181, 137, 0),
    accent2: rgb(38, 139, 210),
    heading: rgb(42, 161, 152),
    bullet: rgb(211, 54, 130),
    text: rgb(238, 232, 213),
    dim: rgb(88, 110, 117),
    gray: rgb(147, 161, 161),
    success: rgb(133, 153, 0),
    error: rgb(220, 50, 47),
    warning: rgb(203, 75, 22),
    user: rgb(38, 139, 210),
    mode_plan: rgb(38, 139, 210),
    mode_build: rgb(133, 153, 0),
    mode_full: rgb(203, 75, 22),
    code_fg: rgb(238, 232, 213),
    code_bg: rgb(0, 43, 54),
    rule: rgb(88, 110, 117),
    add_bg: rgb(30, 52, 38),
    del_bg: rgb(62, 32, 30),
    kw: rgb(133, 153, 0),
    string: rgb(42, 161, 152),
    comment: rgb(88, 110, 117),
    num: rgb(211, 54, 130),
    ty: rgb(181, 137, 0),
    func: rgb(38, 139, 210),
    mac: rgb(220, 50, 47),
    op: rgb(147, 161, 161),
    banner: [rgb(181, 137, 0), rgb(42, 161, 152), rgb(38, 139, 210)],
    border: rgb(88, 110, 117),
    border_focus: rgb(38, 139, 210),
    surface: rgb(20, 62, 74),
    surface_fg: rgb(238, 232, 213),
    hint_key: rgb(38, 139, 210),
    hint_text: rgb(110, 130, 136),
    bar_fill: rgb(42, 161, 152),
    bar_empty: rgb(30, 66, 76),
    overlay: Color::Black,
};

/// Retro-groove warm browns and neons.
pub static GRUVBOX: Theme = Theme {
    name: "gruvbox",
    accent: rgb(184, 187, 38),
    accent2: rgb(142, 192, 124),
    heading: rgb(254, 128, 25),
    bullet: rgb(211, 134, 155),
    text: rgb(235, 219, 178),
    dim: rgb(146, 131, 116),
    gray: rgb(168, 153, 132),
    success: rgb(152, 151, 26),
    error: rgb(251, 73, 52),
    warning: rgb(250, 189, 47),
    user: rgb(131, 165, 152),
    mode_plan: rgb(131, 165, 152),
    mode_build: rgb(184, 187, 38),
    mode_full: rgb(250, 189, 47),
    code_fg: rgb(235, 219, 178),
    code_bg: rgb(40, 40, 40),
    rule: rgb(124, 111, 100),
    add_bg: rgb(48, 52, 34),
    del_bg: rgb(66, 36, 32),
    kw: rgb(251, 73, 52),
    string: rgb(184, 187, 38),
    comment: rgb(146, 131, 116),
    num: rgb(254, 128, 25),
    ty: rgb(250, 189, 47),
    func: rgb(184, 187, 38),
    mac: rgb(211, 134, 155),
    op: rgb(142, 192, 124),
    banner: [rgb(250, 189, 47), rgb(184, 187, 38), rgb(131, 165, 152)],
    border: rgb(124, 111, 100),
    border_focus: rgb(184, 187, 38),
    surface: rgb(66, 60, 52),
    surface_fg: rgb(235, 219, 178),
    hint_key: rgb(250, 189, 47),
    hint_text: rgb(150, 136, 120),
    bar_fill: rgb(184, 187, 38),
    bar_empty: rgb(60, 54, 46),
    overlay: Color::Black,
};

/// Neon dusk city lights.
pub static TOKYO: Theme = Theme {
    name: "tokyo",
    accent: rgb(122, 162, 247),
    accent2: rgb(125, 207, 255),
    heading: rgb(187, 154, 247),
    bullet: rgb(255, 123, 173),
    text: rgb(220, 224, 240),
    dim: rgb(90, 100, 145),
    gray: rgb(150, 160, 200),
    success: rgb(115, 218, 202),
    error: rgb(247, 118, 142),
    warning: rgb(224, 175, 104),
    user: rgb(125, 207, 255),
    mode_plan: rgb(187, 154, 247),
    mode_build: rgb(115, 218, 202),
    mode_full: rgb(224, 175, 104),
    code_fg: rgb(220, 224, 240),
    code_bg: rgb(26, 30, 56),
    rule: rgb(70, 78, 120),
    add_bg: rgb(28, 50, 48),
    del_bg: rgb(58, 32, 46),
    kw: rgb(187, 154, 247),
    string: rgb(158, 206, 106),
    comment: rgb(90, 100, 145),
    num: rgb(255, 158, 100),
    ty: rgb(45, 219, 178),
    func: rgb(122, 162, 247),
    mac: rgb(247, 118, 142),
    op: rgb(125, 207, 255),
    banner: [rgb(255, 123, 173), rgb(187, 154, 247), rgb(122, 162, 247)],
    border: rgb(60, 70, 110),
    border_focus: rgb(122, 162, 247),
    surface: rgb(44, 52, 90),
    surface_fg: rgb(226, 230, 245),
    hint_key: rgb(125, 207, 255),
    hint_text: rgb(112, 122, 165),
    bar_fill: rgb(115, 218, 202),
    bar_empty: rgb(40, 48, 82),
    overlay: Color::Black,
};

/// Muted deep-forest greens.
pub static EVERFOREST: Theme = Theme {
    name: "everforest",
    accent: rgb(167, 192, 128),
    accent2: rgb(115, 170, 140),
    heading: rgb(215, 153, 33),
    bullet: rgb(214, 153, 164),
    text: rgb(211, 216, 190),
    dim: rgb(101, 109, 87),
    gray: rgb(150, 156, 140),
    success: rgb(167, 192, 128),
    error: rgb(228, 44, 44),
    warning: rgb(219, 157, 61),
    user: rgb(115, 170, 140),
    mode_plan: rgb(115, 170, 140),
    mode_build: rgb(167, 192, 128),
    mode_full: rgb(219, 157, 61),
    code_fg: rgb(211, 216, 190),
    code_bg: rgb(43, 48, 45),
    rule: rgb(90, 99, 88),
    add_bg: rgb(46, 58, 44),
    del_bg: rgb(64, 40, 38),
    kw: rgb(228, 44, 44),
    string: rgb(167, 192, 128),
    comment: rgb(101, 109, 87),
    num: rgb(219, 157, 61),
    ty: rgb(115, 170, 140),
    func: rgb(167, 192, 128),
    mac: rgb(214, 153, 164),
    op: rgb(115, 170, 140),
    banner: [rgb(215, 153, 33), rgb(167, 192, 128), rgb(115, 170, 140)],
    border: rgb(90, 99, 88),
    border_focus: rgb(167, 192, 128),
    surface: rgb(56, 62, 52),
    surface_fg: rgb(211, 216, 190),
    hint_key: rgb(167, 192, 128),
    hint_text: rgb(120, 128, 108),
    bar_fill: rgb(167, 192, 128),
    bar_empty: rgb(52, 58, 48),
    overlay: Color::Black,
};

/// Glowing coal-bed reds and oranges.
pub static EMBER: Theme = Theme {
    name: "ember",
    accent: rgb(255, 149, 60),
    accent2: rgb(255, 110, 64),
    heading: rgb(255, 190, 100),
    bullet: rgb(255, 120, 90),
    text: rgb(245, 230, 220),
    dim: rgb(130, 85, 65),
    gray: rgb(195, 150, 125),
    success: rgb(255, 190, 100),
    error: rgb(255, 80, 60),
    warning: rgb(255, 149, 60),
    user: rgb(255, 170, 120),
    mode_plan: rgb(255, 170, 120),
    mode_build: rgb(255, 149, 60),
    mode_full: rgb(255, 210, 130),
    code_fg: rgb(255, 214, 180),
    code_bg: rgb(52, 30, 22),
    rule: rgb(120, 70, 50),
    add_bg: rgb(56, 40, 26),
    del_bg: rgb(64, 26, 22),
    kw: rgb(255, 110, 64),
    string: rgb(255, 190, 100),
    comment: rgb(130, 85, 65),
    num: rgb(255, 210, 130),
    ty: rgb(255, 149, 60),
    func: rgb(255, 190, 100),
    mac: rgb(255, 80, 60),
    op: rgb(255, 170, 120),
    banner: [rgb(255, 210, 130), rgb(255, 149, 60), rgb(200, 60, 40)],
    border: rgb(120, 70, 50),
    border_focus: rgb(255, 149, 60),
    surface: rgb(74, 44, 32),
    surface_fg: rgb(245, 230, 220),
    hint_key: rgb(255, 190, 100),
    hint_text: rgb(150, 108, 88),
    bar_fill: rgb(255, 149, 60),
    bar_empty: rgb(66, 40, 30),
    overlay: Color::Black,
};

/// Pale arctic blues and whites.
pub static ICE: Theme = Theme {
    name: "ice",
    accent: rgb(160, 214, 255),
    accent2: rgb(198, 231, 255),
    heading: rgb(190, 225, 255),
    bullet: rgb(170, 205, 240),
    text: rgb(238, 246, 255),
    dim: rgb(105, 125, 150),
    gray: rgb(170, 190, 210),
    success: rgb(180, 235, 220),
    error: rgb(255, 140, 150),
    warning: rgb(230, 240, 180),
    user: rgb(198, 231, 255),
    mode_plan: rgb(190, 225, 255),
    mode_build: rgb(180, 235, 220),
    mode_full: rgb(230, 240, 180),
    code_fg: rgb(222, 238, 255),
    code_bg: rgb(24, 36, 50),
    rule: rgb(80, 100, 125),
    add_bg: rgb(30, 52, 58),
    del_bg: rgb(58, 34, 42),
    kw: rgb(150, 200, 255),
    string: rgb(185, 235, 220),
    comment: rgb(105, 125, 150),
    num: rgb(230, 240, 180),
    ty: rgb(198, 231, 255),
    func: rgb(160, 214, 255),
    mac: rgb(255, 140, 150),
    op: rgb(198, 231, 255),
    banner: [rgb(198, 231, 255), rgb(160, 214, 255), rgb(110, 150, 200)],
    border: rgb(80, 100, 125),
    border_focus: rgb(160, 214, 255),
    surface: rgb(44, 62, 84),
    surface_fg: rgb(238, 246, 255),
    hint_key: rgb(160, 214, 255),
    hint_text: rgb(130, 150, 175),
    bar_fill: rgb(180, 235, 220),
    bar_empty: rgb(44, 58, 76),
    overlay: Color::Black,
};

/// Matrix-green phosphor on black.
pub static HACKER: Theme = Theme {
    name: "hacker",
    accent: rgb(0, 255, 65),
    accent2: rgb(0, 200, 120),
    heading: rgb(0, 255, 128),
    bullet: rgb(0, 255, 65),
    text: rgb(180, 255, 180),
    dim: rgb(0, 128, 0),
    gray: rgb(0, 160, 80),
    success: rgb(0, 255, 65),
    error: rgb(255, 80, 80),
    warning: rgb(255, 220, 80),
    user: rgb(120, 255, 200),
    mode_plan: rgb(120, 220, 255),
    mode_build: rgb(0, 255, 65),
    mode_full: rgb(255, 220, 80),
    code_fg: rgb(170, 255, 170),
    code_bg: rgb(0, 12, 0),
    rule: rgb(0, 90, 40),
    add_bg: rgb(0, 40, 10),
    del_bg: rgb(50, 10, 10),
    kw: rgb(255, 200, 60),
    string: rgb(120, 255, 200),
    comment: rgb(0, 128, 70),
    num: rgb(255, 240, 120),
    ty: rgb(0, 255, 200),
    func: rgb(0, 255, 65),
    mac: rgb(0, 200, 255),
    op: rgb(0, 255, 65),
    banner: [rgb(0, 255, 65), rgb(0, 200, 120), rgb(0, 90, 20)],
    border: rgb(0, 110, 50),
    border_focus: rgb(0, 255, 65),
    surface: rgb(0, 28, 8),
    surface_fg: rgb(180, 255, 180),
    hint_key: rgb(0, 255, 65),
    hint_text: rgb(0, 150, 80),
    bar_fill: rgb(0, 255, 65),
    bar_empty: rgb(0, 45, 18),
    overlay: Color::Black,
};

/// Catppuccin Mocha — pastel on dark roast.
pub static CATPPUCCIN: Theme = Theme {
    name: "catppuccin",
    accent: rgb(203, 166, 247),
    accent2: rgb(137, 180, 250),
    heading: rgb(137, 180, 250),
    bullet: rgb(245, 194, 231),
    text: rgb(205, 214, 244),
    dim: rgb(108, 112, 134),
    gray: rgb(147, 153, 178),
    success: rgb(166, 227, 161),
    error: rgb(243, 139, 168),
    warning: rgb(249, 226, 175),
    user: rgb(137, 220, 235),
    mode_plan: rgb(137, 180, 250),
    mode_build: rgb(166, 227, 161),
    mode_full: rgb(249, 226, 175),
    code_fg: rgb(205, 214, 244),
    code_bg: rgb(24, 24, 37),
    rule: rgb(69, 71, 90),
    add_bg: rgb(30, 60, 45),
    del_bg: rgb(70, 32, 48),
    kw: rgb(203, 166, 247),
    string: rgb(166, 227, 161),
    comment: rgb(108, 112, 134),
    num: rgb(250, 179, 135),
    ty: rgb(249, 226, 175),
    func: rgb(137, 180, 250),
    mac: rgb(243, 139, 168),
    op: rgb(137, 220, 235),
    banner: [rgb(203, 166, 247), rgb(245, 194, 231), rgb(137, 180, 250)],
    border: rgb(69, 71, 90),
    border_focus: rgb(203, 166, 247),
    surface: rgb(49, 50, 68),
    surface_fg: rgb(205, 214, 244),
    hint_key: rgb(203, 166, 247),
    hint_text: rgb(108, 112, 134),
    bar_fill: rgb(203, 166, 247),
    bar_empty: rgb(49, 50, 68),
    overlay: Color::Black,
};

/// Rosé Pine — muted rose, pine and gold on ink.
pub static ROSEPINE: Theme = Theme {
    name: "rosepine",
    accent: rgb(235, 188, 186),
    accent2: rgb(156, 207, 216),
    heading: rgb(196, 167, 231),
    bullet: rgb(235, 188, 186),
    text: rgb(224, 222, 244),
    dim: rgb(110, 108, 134),
    gray: rgb(144, 140, 170),
    success: rgb(156, 207, 216),
    error: rgb(235, 111, 146),
    warning: rgb(246, 193, 119),
    user: rgb(156, 207, 216),
    mode_plan: rgb(196, 167, 231),
    mode_build: rgb(156, 207, 216),
    mode_full: rgb(246, 193, 119),
    code_fg: rgb(224, 222, 244),
    code_bg: rgb(31, 29, 46),
    rule: rgb(64, 61, 82),
    add_bg: rgb(42, 78, 82),
    del_bg: rgb(80, 42, 58),
    kw: rgb(196, 167, 231),
    string: rgb(156, 207, 216),
    comment: rgb(110, 108, 134),
    num: rgb(246, 193, 119),
    ty: rgb(235, 188, 186),
    func: rgb(156, 207, 216),
    mac: rgb(235, 111, 146),
    op: rgb(144, 140, 170),
    banner: [rgb(235, 188, 186), rgb(196, 167, 231), rgb(49, 116, 143)],
    border: rgb(64, 61, 82),
    border_focus: rgb(235, 188, 186),
    surface: rgb(38, 35, 58),
    surface_fg: rgb(224, 222, 244),
    hint_key: rgb(235, 188, 186),
    hint_text: rgb(110, 108, 134),
    bar_fill: rgb(235, 188, 186),
    bar_empty: rgb(38, 35, 58),
    overlay: Color::Black,
};

/// Ayu dark — vivid orange, green and blue on deep slate.
pub static AYU: Theme = Theme {
    name: "ayu",
    accent: rgb(255, 180, 84),
    accent2: rgb(57, 186, 230),
    heading: rgb(57, 186, 230),
    bullet: rgb(210, 166, 255),
    text: rgb(191, 200, 213),
    dim: rgb(90, 100, 115),
    gray: rgb(130, 140, 155),
    success: rgb(170, 217, 76),
    error: rgb(242, 98, 107),
    warning: rgb(255, 180, 84),
    user: rgb(57, 186, 230),
    mode_plan: rgb(57, 186, 230),
    mode_build: rgb(170, 217, 76),
    mode_full: rgb(255, 180, 84),
    code_fg: rgb(191, 200, 213),
    code_bg: rgb(15, 20, 25),
    rule: rgb(50, 58, 68),
    add_bg: rgb(30, 60, 40),
    del_bg: rgb(70, 30, 35),
    kw: rgb(255, 180, 84),
    string: rgb(170, 217, 76),
    comment: rgb(90, 100, 115),
    num: rgb(210, 166, 255),
    ty: rgb(255, 200, 120),
    func: rgb(57, 186, 230),
    mac: rgb(242, 98, 107),
    op: rgb(130, 140, 155),
    banner: [rgb(255, 180, 84), rgb(170, 217, 76), rgb(57, 186, 230)],
    border: rgb(50, 58, 68),
    border_focus: rgb(255, 180, 84),
    surface: rgb(28, 35, 43),
    surface_fg: rgb(191, 200, 213),
    hint_key: rgb(255, 180, 84),
    hint_text: rgb(90, 100, 115),
    bar_fill: rgb(255, 180, 84),
    bar_empty: rgb(28, 35, 43),
    overlay: Color::Black,
};

/// One Dark — Atom's balanced red/green/blue on charcoal.
pub static ONEDARK: Theme = Theme {
    name: "onedark",
    accent: rgb(97, 175, 239),
    accent2: rgb(198, 120, 221),
    heading: rgb(97, 175, 239),
    bullet: rgb(224, 108, 117),
    text: rgb(171, 178, 191),
    dim: rgb(92, 99, 112),
    gray: rgb(124, 131, 145),
    success: rgb(152, 195, 121),
    error: rgb(224, 108, 117),
    warning: rgb(229, 192, 123),
    user: rgb(86, 182, 194),
    mode_plan: rgb(97, 175, 239),
    mode_build: rgb(152, 195, 121),
    mode_full: rgb(229, 192, 123),
    code_fg: rgb(171, 178, 191),
    code_bg: rgb(33, 37, 43),
    rule: rgb(62, 68, 81),
    add_bg: rgb(35, 65, 50),
    del_bg: rgb(70, 38, 45),
    kw: rgb(198, 120, 221),
    string: rgb(152, 195, 121),
    comment: rgb(92, 99, 112),
    num: rgb(209, 154, 102),
    ty: rgb(229, 192, 123),
    func: rgb(97, 175, 239),
    mac: rgb(224, 108, 117),
    op: rgb(86, 182, 194),
    banner: [rgb(97, 175, 239), rgb(198, 120, 221), rgb(224, 108, 117)],
    border: rgb(62, 68, 81),
    border_focus: rgb(97, 175, 239),
    surface: rgb(44, 49, 60),
    surface_fg: rgb(171, 178, 191),
    hint_key: rgb(97, 175, 239),
    hint_text: rgb(92, 99, 112),
    bar_fill: rgb(97, 175, 239),
    bar_empty: rgb(44, 49, 60),
    overlay: Color::Black,
};

pub static ALL: &[&Theme] = &[
    &LAUDA,
    &CHERRY,
    &MIDNIGHT,
    &NORD,
    &DRACULA,
    &MONOKAI,
    &SOLARIZED,
    &GRUVBOX,
    &TOKYO,
    &EVERFOREST,
    &EMBER,
    &ICE,
    &HACKER,
    &CATPPUCCIN,
    &ROSEPINE,
    &AYU,
    &ONEDARK,
];
pub static DEFAULT: &Theme = &LAUDA;

pub fn names() -> Vec<&'static str> {
    ALL.iter().map(|t| t.name).collect()
}

/// Currently active theme (defaults to Lauda until [`set`] succeeds).
pub fn get() -> &'static Theme {
    ACTIVE.with(|c| *c.borrow()).unwrap_or(DEFAULT)
}

/// Switch the active theme by name. Returns false for unknown names.
pub fn set(name: &str) -> bool {
    let found = ALL
        .iter()
        .find(|t| t.name.eq_ignore_ascii_case(name.trim()))
        .copied();
    // A failed lookup must leave the current choice untouched.
    if let Some(t) = found {
        ACTIVE.with(|c| *c.borrow_mut() = Some(t));
    }
    found.is_some()
}

thread_local! {
    static ACTIVE: std::cell::RefCell<Option<&'static Theme>> =
        const { std::cell::RefCell::new(None) };
}

/// Interpolate the banner gradient stops into `rows` colors (RGB lerp).
pub fn banner_gradient(rows: usize) -> Vec<Color> {
    let [top, mid, bot] = get().banner;
    let stops = [top, mid, bot];
    let mut out = Vec::with_capacity(rows);
    for i in 0..rows {
        let pos = if rows <= 1 {
            0.0
        } else {
            i as f32 / (rows - 1) as f32
        };
        let seg = (pos * 2.0).min(1.999);
        let idx = seg as usize;
        let t = seg - idx as f32;
        out.push(lerp(stops[idx], stops[idx + 1], t));
    }
    out
}

fn lerp(a: Color, b: Color, t: f32) -> Color {
    match (a, b) {
        (Color::Rgb(r1, g1, b1), Color::Rgb(r2, g2, b2)) => Color::Rgb(
            (r1 as f32 + (r2 as f32 - r1 as f32) * t) as u8,
            (g1 as f32 + (g2 as f32 - g1 as f32) * t) as u8,
            (b1 as f32 + (b2 as f32 - b1 as f32) * t) as u8,
        ),
        _ => {
            // Named colors can't lerp — snap halfway.
            if t < 0.5 {
                a
            } else {
                b
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn all_themes_resolve_and_names_unique() {
        let mut seen = std::collections::HashSet::new();
        for t in ALL {
            assert!(seen.insert(t.name), "duplicate theme {}", t.name);
            assert!(set(t.name));
            assert_eq!(get().name, t.name);
        }
        assert_eq!(names().len(), ALL.len());
    }

    #[test]
    fn unknown_theme_falls_back_to_default_without_swapping() {
        set("cherry");
        assert!(!set("nope"));
        assert_eq!(get().name, "cherry", "failed set must not change theme");
        set("lauda");
        assert!(!get().name.is_empty());
    }

    #[test]
    fn gradient_has_one_entry_per_row() {
        set("lauda");
        assert_eq!(banner_gradient(13).len(), 13);
        assert_eq!(banner_gradient(6).len(), 6);
    }

    #[test]
    fn themes_differ_in_syntax_palette() {
        set("lauda");
        let lauda_kw = get().kw;
        set("dracula");
        let dracula_kw = get().kw;
        assert_ne!(lauda_kw, dracula_kw);
        set("lauda");
    }
}
